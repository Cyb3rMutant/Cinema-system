#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ˅
import film
import show
from dbfunc import conn

# ˄


class Listing(object):
    def __init__(self, listing_id, date, film, cinema):
        self.__listing_id = listing_id

        self.__date = date

        self.__film = film

        self.__cinema = cinema

        self.__shows = dict()

        shows = conn.select("SELECT * FROM shows WHERE LISTING_ID=%s",
                            self.__listing_id)
        for s in shows:
            print(cinema.get_screens()[s["SCREEN_ID"]])
            self.__shows[s["SHOW_ID"]] = show.Show(
                s["SHOW_ID"], s["SHOW_TIME"], cinema.get_screens()[s["SCREEN_ID"]], self)

    def get_listing_id(self):
        return self.__listing_id

    def get_date(self):
        return self.__date

    def get_film(self):
        return self.__film

    def get_cinema(self):
        return self.__cinema

    def get_shows(self):
        return self.__shows

    def set_date(self, date):
        self.__date = date

    def set_film(self, film):
        self.__film = film

    def update_show_time(self, show_id, time):
        conn.update("UPDATE shows SET SHOW_TIME=%s WHERE SHOW_ID=%s",
                    time, show_id)
        self.__time

    def __str__(self):
        return f"listing_id: {self.__listing_id} date: {self.__date} film: {self.__film}"
