#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ˅
import book_ticket


# ˄


class Book_ticket_admin(book_ticket.Book_ticket):
    # ˅

    # ˄

    def __choose_cinema(self, cities):
        # ˅
        pass
        # ˄

    # ˅

    # ˄


# ˅

# ˄
