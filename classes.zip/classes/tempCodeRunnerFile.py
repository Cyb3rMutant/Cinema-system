import tkinter as tk
from tktimepicker import AnalogPicker, AnalogThemes
# note: you can also make use of mouse wheel or keyboard to scroll or enter the spin timepicker
root = tk.Tk()

time_picker = AnalogPicker(root)
time_picker.pack(expand=True, fill="both")

theme = AnalogThemes(time_picker)
theme.setDracula()

root.mainloop()
