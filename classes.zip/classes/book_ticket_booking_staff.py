#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ˅
import book_ticket


# ˄


class Book_ticket_booking_staff(book_ticket.Book_ticket):
    # ˅

    # ˄

    def __choose_cinema(self, branch):
        # ˅
        pass
        # ˄

    # ˅

    # ˄


# ˅

# ˄
