class Receipt_generator():
    def __init__(self, booking):

        self.__booking = booking

    def gen_receipt(self):
        pass
