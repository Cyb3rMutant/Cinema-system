class Generate_report(object):
    def num_bookings(self):
        pass

    def monthly_revenue(self):
        pass

    def top_film_revenue(self):
        pass

    def staff_revenue(self):
        pass
