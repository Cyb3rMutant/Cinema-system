#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ˅
import show


# ˄


class Book_ticket(object):
    # ˅

    # ˄

    def make_booking(self):
        # ˅
        pass
        # ˄

    def __choose_cinema(self):
        # ˅
        pass
        # ˄

    def __check_availability(self):
        # ˅
        pass
        # ˄

    def __check_price(self):
        # ˅
        pass
        # ˄

    # ˅

    # ˄


# ˅

# ˄
