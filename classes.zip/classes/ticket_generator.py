class Ticket_generator(object):
    def __init__(self, booking):

        self.__booking = booking
        pass

    def gen_ticket(self):
        pass
